public class Agenda {
    
    public static void inclusao(String nome, String email, int telefone) {
    System.out.println("Nome: " + nome);
    System.out.println("Email: " + email);
    System.out.println("Telefone: " + telefone);
}

public static void excluir(String nome, String email, int telefone) {
    System.out.println(nome + email + telefone); 
    //teste para ver se aparece os dados
    System.out.println("Nome: " + nome);
    System.out.println("Email: " + email);
    System.out.println("Telefone: " + telefone);
}

public static void listar() {
    //...
}

}
