public class teste {

    public static void main(String[] args) {
        
        System.out.println("Iniciando o teste da agenda...");
        
        Agenda.inclusao("Maria", "maria@mail.com", 11223344);
        
        // Chamando excluir() da classe Agenda
        Agenda.excluir("João", "joao@mail.com", 55667788);
        Agenda.listar();
        Agenda.excluir("Maria", "maria@mail.com", 11223344);
        Agenda.listar();
        Agenda.excluir("Davi", "davi@gmail.com", 123456789);
        Agenda.listar();
        
        Agenda.listar();
        
        System.out.println("Teste finalizado.");
    }
}