public class Contato {
    
    public String nome = "Davi";
    public int telefone = 1234567890;
    public String email = "davi@gmail.com";

}
